# socionics
A brief test to determine your type of socionics.
